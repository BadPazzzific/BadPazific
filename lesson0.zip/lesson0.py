# '1st program'
print( 9 ** 0.5 * 5)
# '2nd program'
print (9.99 > 9.98 and 1000 != 1000.1)
# '3rd program
print (2 * 2 + 2)
print (2 * (2 + 2))
print ((2 * 2 + 2) == (2 * (2 + 2)))
# '4th program
print (float ('123.456'))
print (float ('123.456') * 10) #тут я зашел в тупик
